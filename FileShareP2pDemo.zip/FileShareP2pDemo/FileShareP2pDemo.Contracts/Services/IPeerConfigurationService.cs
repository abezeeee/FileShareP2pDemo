﻿using FileShareP2pDemo.Domain.Models;

namespace FileShareP2pDemo.Contracts.Services
{
    public interface IPeerConfigurationService 
    {
        int Port { get; }
        Peer<IPingService> Peer { get; }
        bool StartPeerService();
        bool StopPeerService();
    }
}
