﻿using FileShareP2pDemo.Domain.Models;
using System.Net.PeerToPeer.Collaboration;

namespace FileShareP2pDemo.Contracts.Repository
{
    public interface IPeerNameResolverRepository 
    {
        void ResolvePeerName();
        PeerEndPointsCollection PeerEndPointCollection { get; set; }
    }
}
