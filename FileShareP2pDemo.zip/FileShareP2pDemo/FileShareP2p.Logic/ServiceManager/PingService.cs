﻿using FileShareP2pDemo.Contracts.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileShareP2p.Logic.ServiceManager
{
    public class PingService : IPingService
    {
        public void Ping(int port, string peerUri)
        {
            Console.WriteLine($"Say Hi ! From: {peerUri}");
        }
    }
}
