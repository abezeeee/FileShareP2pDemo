﻿using FileShareP2p.Logic.ServiceManager;
using FileShareP2pDemo.Contracts.Repository;
using FileShareP2pDemo.Contracts.Services;
using FileShareP2pDemo.Domain.Models;
using FileShareP2pDemo.Logics.PnrpManager;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileShareP2pDemo.Test
{
    class Program
    {
        static void Main(string[] args)
        {
            if(Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName).Count()<=1)
            {
                Process.Start("FileShareP2pDemo.Test.exe");
            }
            new Program().Run();
        }

        private void Run()
        {
            Peer<IPingService> peer = new Peer<IPingService> { Username = Guid.NewGuid().ToString().Split('-')[4]};
            IPeerRegistrationRepositotory peerRegistration = new PeerRegistrationManager();
            IPeerNameResolverRepository peerNameResolver = new PeerNameResolver(peer.Username);
            IPeerConfigurationService peerConfigurationService = new PeerConfigurationService(peer);
            peerRegistration.StartPeerRegistration(peer.Username, peerConfigurationService.Port);

            Console.WriteLine("Peer Information");
            Console.WriteLine($"Peer Uri : {peerRegistration.PeerUri} Port : {peerConfigurationService.Port}");
            Console.ReadLine();
        }
    }
}
